import React from 'react'
import p4 from "../img/p-4.webp"
import { Link } from 'react-router-dom';
import { addItem } from '../utils/cartSlice';
import { useDispatch } from 'react-redux';

const Product = ({id, title, desc, price, imgSrc, category}) => {

  const dispatch = useDispatch();

  const truncateTitle = (title, limit) => {
    const words = title.split(' ');
    if (words.length > limit) {
      return words.slice(0, limit).join(' ') + '...';
    }
    return title;
  };

  const truncatedTitle = truncateTitle(title, 6);

  const handleAddToCart = () => {
    // Dispatch addItem action with the product details as payload
    dispatch(addItem({ id, title, price, imgSrc, category }));
  };

  return (
    <>
        <div className='group box-border border border-gray-300 rounded-lg overflow-hidden flex p-5 cursor-pointer ltr:pr-0 rtl:pl-0 pb-2 lg:pb-3 flex-col items-start transition duration-200 ease-in-out transform hover:-translate-y-1 md:hover:-translate-y-1.5 hover:shadow-product  bg-white'>
            <img  className="w-full h-full object-contain" src={imgSrc}/>
            <h6 className='uppercase mt-2'>{category}</h6>
            <h2 className='mb-1 text-sm md:text-base font-semibold text-heading min-h-[4.5rem] text-left'>
              <Link to={`/product/${id}`}>{truncatedTitle}</Link>
            </h2>
            <span className='inline-block false'>₹ {price}</span>
            <button onClick={handleAddToCart} className='text-[13px] bg-green mt-2 md:text-sm leading-4 inline-flex items-center font-semibold font-body text-center justify-center border-0 border-transparent focus-visible:outline-none focus:outline-none rounded-md  bg-heading text-white md:px-6 lg:px-8 py-4 md:py-3.5 lg:py-4 hover:text-white hover:bg-gray-600 hover:shadow-cart w-full h-11 md:h-12 px-1.5'>Add To Cart</button>
        </div>
    </>
  )
}

export default Product