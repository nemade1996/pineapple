import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeItem, updateQuantity, clearCart } from '../utils/cartSlice';

const Cart = () => {
    const dispatch = useDispatch();
    const cartItems = useSelector((state) => state.cart);

    // Define shipping charge
    const shippingCharge = 10;

    const removeCartItem = (id) => {
        dispatch(removeItem(id));
    };

    const handleQuantityChange = (e, id) => {
        const quantity = parseInt(e.target.value);
        dispatch(updateQuantity({ id, quantity }));
    };

    const calculateTotal = (item) => {
        return item.price * item.quantity;
    };

    const calculateSubtotal = () => {
        return cartItems.reduce((acc, item) => acc + calculateTotal(item), 0);
    };

    const calculateFinalTotal = () => {
        return calculateSubtotal() + shippingCharge;
    };

    const handleClearCart = () => {
        dispatch(clearCart());
    };

    return (
        <div>
            <div className="flex flex-wrap w-full">
                {cartItems.length > 0 ? (
                    <form action="#" className="w-full">
                        <div className="table-content cart-table-content">
                            <table className="w-full bg-[#fff]">
                                <thead>
                                    <tr className="bg-[#fff] border-b-2 border-solid border-[#eee]">
                                        <th className="px-4 py-3 text-left text-[#4b5966] font-medium">Product</th>
                                        <th className="px-4 py-3 text-left text-[#4b5966] font-medium">Name</th>
                                        <th className="px-4 py-3 text-left text-[#4b5966] font-medium">Price</th>
                                        <th className="px-4 py-3 text-center text-[#4b5966] font-medium">Quantity</th>
                                        <th className="px-4 py-3 text-left text-[#4b5966] font-medium">Total</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {cartItems.map((item) => (
                                        <tr key={item.id} className="border-b-1 border-solid border-[#eee]">
                                            <td className="px-4 py-3 text-left">
                                                <img className="w-16 h-16" src={item.imgSrc} alt={item.title} />
                                            </td>
                                            <td className="px-4 py-3 text-left">{item.title}</td>
                                            <td className="px-4 py-3 text-left">{item.price}</td>
                                            <td className="px-4 py-3 text-center">
                                                <input
                                                    className="border border-gray-300 rounded px-2 py-1"
                                                    type="number"
                                                    value={item.quantity}
                                                    onChange={(e) => handleQuantityChange(e, item.id)}
                                                />
                                            </td>
                                            <td className="px-4 py-3 text-left">{calculateTotal(item)}</td>
                                            <td className="px-4 py-3 text-right">
                                                <button
                                                    className="text-[#4b5966] hover:text-[#000] underline"
                                                    onClick={() => removeCartItem(item.id)}
                                                >
                                                    Remove
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div className="flex flex-wrap">
                            <div className="w-full">
                                <div className="pt-4 flex justify-between">
                                    <div className="text-[#4b5966]">
                                        <span>Subtotal: ${calculateSubtotal()}</span><br />
                                        <span>Shipping: ${shippingCharge}</span><br />
                                        <span className="font-bold">Total: ${calculateFinalTotal()}</span>
                                    </div>
                                    <div>
                                        <button
                                            type="button"
                                            className="px-4 py-2 mr-4 bg-[#d9534f] text-white rounded transition-colors duration-300 hover:bg-[#c9302c]"
                                            onClick={handleClearCart}
                                        >
                                            Clear Cart
                                        </button>
                                        <button
                                            type="button"
                                            className="px-4 py-2 bg-[#5caf90] text-white rounded transition-colors duration-300 hover:bg-[#4b5966]"
                                        >
                                            Checkout
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                ) : (
                    <div className="w-full text-center py-20">
                        <h2 className="text-[24px] text-[#4b5966] mb-4">Your cart is empty</h2>
                        <a href="#" className="text-[#5caf90] underline">Continue Shopping</a>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Cart;
