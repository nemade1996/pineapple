import React from 'react'
import Product from './Product'
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const ProductGrid = () => {

    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchProducts();
      }, []);

    const fetchProducts = async ()=>{
        try {
          const response = await fetch('https://fakestoreapi.com/products');
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          const data = await response.json();
          
        console.log(data)
          setProducts(data);
        } catch (err) {
          setError(err.message);
        } finally {
          setLoading(false);
        }

      };

     

    // const {name, description, price } = bestList;

  return (
    <div className='grid mt-20 grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-x-3 lg:gap-x-5 xl:gap-x-7 gap-y-3 xl:gap-y-5 2xl:gap-y-8 '>

        {
            products.map((product)=>(
                <Product  key={product.id} id={product.id} title={product.title} price={product.price} imgSrc={product.image} category={product.category}/>
            ))
        }

        
    </div>
  )
}

export default ProductGrid