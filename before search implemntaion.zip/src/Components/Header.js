import React from 'react'
import logo from "../img/logo.png"
import search from "../img/search.svg"
import cart from "../img/cart.svg"
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import ProductPopup from './ProductPopup'

const Header = () => {
  const totalItem = useSelector((state)=>state.cart)
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  const handleInputChange = (event) => {
    setSearchTerm(event.target.value);
    // Additional logic for filtering/searching products can be added here
  };

  return (
    <div className='shadow-lg container'>
      <div className="relative z-20 w-full h-16 sm:h-20 lg:h-24">
        <div className="flex z-20 w-full h-16 px-4 text-gray-700 bg-white sm:h-20 lg:h-24 md:px-8 lg:px-6">
          <div className="flex justify-start items-center mx-auto max-w-[1920px] h-full w-full">
            <Link className="inline-flex focus:outline-none" to="/">
              <img src={logo} className='w-28'/>
            </Link>
          </div>
          <nav className="headerMenu flex w-full relative lg:flex ltr:md:ml-6 rtl:md:mr-6 ltr:xl:ml-10 rtl:xl:mr-10">
            <ul className="flex my-12 ">
              <li className='mb-1 px-2  cursor-pointer bg-white text-gray-lite font-medium mx-2.5 flex text-xtiny md:px-4 xl:px-5 items-center '><Link to="/">Home</Link></li>
              <li className='mb-1 px-2  cursor-pointer bg-white text-gray-lite font-medium mx-2.5 flex text-xtiny md:px-4 xl:px-5 items-center'><Link to="/about">About</Link></li>
              <li className='mb-1 px-2  cursor-pointer bg-white text-gray-lite font-medium mx-2.5 flex text-xtiny md:px-4 xl:px-5 items-center'><Link to="/products">Products</Link></li>
              <li className='mb-1 px-2  cursor-pointer bg-white text-gray-lite font-medium mx-2.5 flex text-xtiny md:px-4 xl:px-5 items-center'>Contact</li>
            </ul>
          </nav>
          <div className="items-center justify-end flex-shrink-0 hidden lg:flex gap-x-6 lg:gap-x-5 xl:gap-x-8 2xl:gap-x-10 ltr:ml-auto rtl:mr-auto">
          <div className="relative flex">
            {/* Search Input */}
            <input
              type="text"
              className="border border-gray-300 rounded-l py-2 px-4 w-64 focus:outline-none"
              placeholder="Search products..."
              value={searchTerm}
              onChange={handleInputChange}
            />

            {/* Search Button */}
            <button
              className="flex items-center justify-center flex-shrink-0 h-12 w-12 bg-gray-200 text-gray-700 rounded-r transform focus:outline-none"
              aria-label="search-button"
              onClick={togglePopup}
            >
              <img src={search} alt="search icon" className="h-6 w-6" />
            </button>

            {/* Conditionally render the popup based on showPopup state */}
            {showPopup && <ProductPopup searchTerm={searchTerm} />}
          </div>
            {showPopup && <ProductPopup />}
            <div className="-mt-0.5 flex-shrink-0">
              <Link to="/signin"><button className="text-sm font-semibold xl:text-base text-heading">Sign In</button></Link>
            </div>
            <Link to="/cart">
            <button className="relative flex items-center justify-center flex-shrink-0 h-auto transform focus:outline-none" aria-label="cart-button">
              <img src={cart} />
              <span className="cart-counter-badge">{totalItem.length}</span>
            </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Header