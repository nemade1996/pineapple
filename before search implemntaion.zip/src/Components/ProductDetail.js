import React from 'react'
import { useParams } from 'react-router-dom'
import { useEffect } from 'react';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addItem } from '../utils/cartSlice';

const ProductDetail = () => {
  const { productId } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const dispatch = useDispatch();

  useEffect(() => {
    const fetchProduct = async (id) => {
      try {
        const response = await fetch(`https://fakestoreapi.com/products/${id}`);
        console.log(response)
        
        // if (!response.ok) {
        //   throw new Error('Network response was not ok');
        // }

        const data = await response.json();
        setProduct(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct(productId);
  }, [productId]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  if (!product) {
    return <div>No product found</div>;
  }

  const handleAddToCart = ()=>{
    console.log(product)
    dispatch(addItem(product))
  }


    return (
        <div>
          <div className='relative flex-grow'>
            <div className='mx-auto max-w-[1920px] px-4 md:px-8 2xl:px-16'>
              <div className='block lg:grid grid-cols-9 gap-x-10 xl:gap-x-14 pt-7 pb-10 lg:pb-14 2xl:pb-20 items-start'>
                <div className='col-span-4 grid-cols-2 gap-2.5 flex justify-center items-center'>
                  <img src={product.image} className="max-w-full max-h-full w-4/5"/>
                </div>
                <div className='col-span-5 pt-8 lg:pt-0'>
                  <div className="pb-7 mb-7 border-b border-gray-300 text-center mt-16">
                    <h2 className="text-heading text-left text-lg md:text-xl lg:text-3xl font-bold hover:text-black mb-3.5">{product.title}</h2>
                    <h6 className="text-heading text-left text-md md:text-xl lg:text-xl font-bold hover:text-black mb-3.5">{product.category}</h6>
                  </div>
                  <div className="pb-7 mb-7 border-b border-gray-300">
                    <p className="text-body text-left text-sm lg:text-base leading-6 lg:leading-8">{product.description}</p>
                    <div className="flex items-center mt-5">
                      <div className="text-heading font-bold text-base md:text-xl lg:text-2xl 2xl:text-4xl ltr:pr-2 rtl:pl-2 ltr:md:pr-0 rtl:md:pl-0 ltr:lg:pr-2 rtl:lg:pl-2 ltr:2xl:pr-0 rtl:2xl:pl-0">{product.price}</div>
                    </div>
                  </div>
                  <button onClick={handleAddToCart} className='float-left text-[13px] bg-green mt-2 md:text-sm leading-4 font-semibold font-body text-center justify-center border-0 border-transparent focus-visible:outline-none focus:outline-none rounded-md  bg-heading text-white md:px-6 lg:px-8 py-4 md:py-3.5 lg:py-4 hover:text-white hover:bg-gray-600 hover:shadow-cart h-11 md:h-12 px-1.5'>Add To Cart</button>
                  <div class="group flex items-center justify-between rounded-md overflow-hidden flex-shrink-0 border h-11 md:h-12 border-gray-300">
                    <button class="flex items-center justify-center flex-shrink-0 h-full transition ease-in-out duration-300 focus:outline-none w-10 md:w-12 text-heading border-e border-gray-300 hover:text-white hover:bg-heading" disabled="">
                      +
                    </button>
                    <span class="font-semibold flex items-center justify-center h-full  transition-colors duration-250 ease-in-out cursor-default flex-shrink-0 text-base text-heading w-12  md:w-20 xl:w-24">1</span>
                    <button class="flex items-center justify-center h-full flex-shrink-0 transition ease-in-out duration-300 focus:outline-none w-10 md:w-12 text-heading border-s border-gray-300 hover:text-white hover:bg-heading">
                      -
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    )
}

export default ProductDetail