import React from 'react'

const ProductPopup = ({ searchTerm }) => {
    console.log(searchTerm)
    const products = [
        { id: 1, name: 'Product A', price: '$10', image: 'product_a.jpg' },
        { id: 2, name: 'Product B', price: '$15', image: 'product_b.jpg' },
        { id: 3, name: 'Product C', price: '$20', image: 'product_c.jpg' },
      ];

  return (
    <div>
        <div className="absolute top-[100px] right-0 w-[60%] bg-white border border-gray-300 shadow-lg rounded-lg z-10">
      <div className="px-4 py-2 font-semibold border-b border-gray-300">Products</div>
      <div className="divide-y divide-gray-300">
        {products.map(product => (
          <div key={product.id} className="p-4 flex items-center justify-between space-x-4">
            <img src={product.image} alt={product.name} className="w-16 h-16 object-cover rounded-lg" />
            <div>
              <div className="font-semibold">{product.name}</div>
              <div className="text-gray-600">{product.price}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
    </div>
  )
}

export default ProductPopup