
import './App.css';
import Header from './Components/Header';
import Slider from './Components/Slider';
import ProductGrid from './Components/ProductGrid';
import ReactDOM from 'react-dom/client';
import { Outlet, createBrowserRouter } from 'react-router-dom';
import { RouterProvider } from 'react-router-dom';
import Error from './Components/Error';
import Intro from './Components/Intro';
import About from './Components/About';
import Products from './Components/Products';
import SignIn from './Components/SignIn';
import ProductDetail from './Components/ProductDetail';
import { Provider } from 'react-redux';
import appStore from './utils/appStore';
import Cart from './Components/Cart';

function App() {

  return (
    <Provider store = {appStore}>
      <div className="App">
        <div className='container'>
          <Header/>
          <Outlet/>
        </div>
      </div>
    </Provider>
  );
}


const appRouter = createBrowserRouter([
  {
    path: "/",
    element:<App/>,
    children:[
      {
        path: "/",
        element:<Intro/>
      },
      {
        path: "/about",
        element:<About/>
      },
      {
        path: "/products",
        element:<Products/>
      },
      {
        path: "/signin",
        element:<SignIn/>
      },
      {
        path: "/product/:productId",
        element:<ProductDetail/>
      },
      {
        path: "/cart",
        element:<Cart/>
      },
  ],

  errorElement : <Error/>
  }, 
])

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <RouterProvider router={appRouter}/>
)


export default App;
