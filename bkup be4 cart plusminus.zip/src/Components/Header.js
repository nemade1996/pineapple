import React from 'react'
import logo from "../img/logo.svg"
import search from "../img/search.svg"
import cart from "../img/cart.svg"
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'

const Header = () => {
  const totalItem = useSelector((state)=>state.cart)
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <div className='shadow-lg'>
      <div className="relative z-20 w-full h-16 sm:h-20 lg:h-24">
        <div className="flex z-20 w-full h-16 px-4 text-gray-700 bg-white sm:h-20 lg:h-24 md:px-8 lg:px-6">
          <div className="flex justify-start items-center mx-auto max-w-[1920px] h-full w-full">
            <Link className="inline-flex focus:outline-none" to="/">
              <img src={logo} />
            </Link>
          </div>
          <nav className="headerMenu flex w-full relative lg:flex ltr:md:ml-6 rtl:md:mr-6 ltr:xl:ml-10 rtl:xl:mr-10">
            <ul className="flex my-12 ">
              <li className='mb-1 px-2  cursor-pointer bg-white text-gray-lite font-medium mx-2.5 flex text-xtiny md:px-4 xl:px-5 items-center '><Link to="/">Home</Link></li>
              <li className="relative group mb-1 px-2 cursor-pointer bg-white text-gray-lite font-medium mx-2.5 flex text-xtiny md:px-4 xl:px-5 items-center">
                <button className="text-gray-800 focus:outline-none">
                  Products
                </button>
                <div className="absolute top-10 right-0 mt-2 w-48 bg-white border rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <a to="/product1" className="block px-4 py-2 text-gray-800 hover:bg-gray-200">Product 1</a>
                  <a to="/product2" className="block px-4 py-2 text-gray-800 hover:bg-gray-200">Product 2</a>
                  <a to="/product3" className="block px-4 py-2 text-gray-800 hover:bg-gray-200">Product 3</a>
                </div>
              </li>
              <li className='mb-1 px-2  cursor-pointer bg-white text-gray-lite font-medium mx-2.5 flex text-xtiny md:px-4 xl:px-5 items-center'><Link to="/about">About</Link></li>
              <li className='mb-1 px-2  cursor-pointer bg-white text-gray-lite font-medium mx-2.5 flex text-xtiny md:px-4 xl:px-5 items-center'><Link to="/products">Products</Link></li>
              <li className='mb-1 px-2  cursor-pointer bg-white text-gray-lite font-medium mx-2.5 flex text-xtiny md:px-4 xl:px-5 items-center'>Contact</li>
            </ul>
          </nav>
          <div className="items-center justify-end flex-shrink-0 hidden lg:flex gap-x-6 lg:gap-x-5 xl:gap-x-8 2xl:gap-x-10 ltr:ml-auto rtl:mr-auto">
            <button className="relative flex items-center justify-center flex-shrink-0 h-auto transform focus:outline-none" aria-label="search-button">
              <img src={search} />
            </button>
            <div className="-mt-0.5 flex-shrink-0">
              <Link to="/signin"><button className="text-sm font-semibold xl:text-base text-heading">Sign In</button></Link>
            </div>
            <Link to="/cart">
            <button className="relative flex items-center justify-center flex-shrink-0 h-auto transform focus:outline-none" aria-label="cart-button">
              <img src={cart} />
              <span className="cart-counter-badge flex items-center justify-center bg-heading text-white bg-black p-1 absolute h-30 w-30 -top-2 right-[-10px] xl:-top-3 rounded-full ltr:-right-2.5 ltr:xl:-right-3 rtl:-left-2.5 rtl:xl:-left-3 font-bold">{totalItem.length}</span>
            </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Header