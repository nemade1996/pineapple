import logo from './logo.svg';
import './App.css';
import Header from './Components/Header';
import Slider from './Components/Slider';
import ProductGrid from './Components/ProductGrid';
import ReactDOM from 'react-dom';
import { Outlet, createBrowserRouter } from 'react-router-dom';
import { RouterProvider } from 'react-router-dom';
import Error from './Components/Error';
import Intro from './Components/Intro';
import About from './Components/About';
import Products from './Components/Products';
import SignIn from './Components/SignIn';

function App() {

  

  

  return (
    <div className="App">
      <div className='container'>
        <Header/>
        <Outlet/>
      </div>
    </div>
  );
}


const appRouter = createBrowserRouter([
  {
    path: "/",
    element:<App/>,
    children:[
      {
        path: "/",
        element:<Intro/>
      },
      {
        path: "/about",
        element:<About/>
      },
      {
        path: "/products",
        element:<Products/>
      },
      {
        path: "/signin",
        element:<SignIn/>
      },
  ],

  errorElement : <Error/>
  }, 
])

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <RouterProvider router={appRouter}/>
)


export default App;
