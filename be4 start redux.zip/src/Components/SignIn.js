import React from 'react'

const SignIn = () => {
  return (
    <div className="relative flex-grow">
      <div className="flex justify-center p-6 md:p-10 2xl:p-8 relative bg-no-repeat bg-center bg-cover">
        <div className="mx-auto max-w-[1920px] px-4 md:px-8 2xl:px-16">
          <div className="py-16 lg:py-20">
            <div className="py-5 px-5 sm:px-8 bg-white mx-auto rounded-lg w-full sm:w-96 md:w-450px border border-gray-300">
              <div className="text-center mb-6 pt-2.5">
                <h2>Sign Up</h2>
              </div>
              <div>
                <form className="flex flex-col justify-center" novalidate="">
                  <div className="flex flex-col space-y-4">
                    <div className="block">
                      <label for="name" className="block text-gray-600 font-semibold text-sm leading-none mb-3 cursor-pointer">Name</label>
                      <input id="name" name="name" type="text" placeholder="" className="py-2 px-4 md:px-5 w-full appearance-none transition duration-150 ease-in-out border text-input text-xs lg:text-sm font-body placeholder-body min-h-12 transition duration-200 ease-in-out bg-white border-gray-300 focus:outline-none focus:border-heading h-11 md:h-12 rounded-md"/>
                    </div>
                    <div className="block">
                      <label for="email" className="block text-gray-600 font-semibold text-sm leading-none mb-3 cursor-pointer">Email</label>
                      <input id="email" name="email" type="email" placeholder="" className="py-2 px-4 md:px-5 w-full appearance-none transition duration-150 ease-in-out border text-input text-xs lg:text-sm font-body placeholder-body min-h-12 transition duration-200 ease-in-out bg-white border-gray-300 focus:outline-none focus:border-heading h-11 md:h-12 rounded-md"/>
                    </div>
                    <div className="block">
                      <label for="password" className="block text-gray-600 font-semibold text-sm leading-none mb-3 cursor-pointer">Password</label>
                      <input id="password" name="password" type="password" className="py-2 px-4 md:px-5 w-full appearance-none transition duration-150 ease-in-out border border-gray-500 text-input text-xs lg:text-sm font-body rounded-md placeholder-gray-600  transition duration-200 ease-in-out bg-white border border-gray-100 focus:outline-none focus:border-heading h-11 md:h-12"/>
                    </div>
                    <button data-variant="flat" className="bg-black text-[13px] md:text-sm leading-4 inline-flex items-center cursor-pointer transition ease-in-out duration-300 font-semibold font-body text-center justify-center border-0 border-transparent placeholder-white focus-visible:outline-none focus:outline-none rounded-md  bg-heading text-white px-5 md:px-6 lg:px-8 py-4 md:py-3.5 lg:py-4 hover:text-white hover:bg-gray-600 hover:shadow-cart h-11 md:h-12 w-full mt-2" type="submit">Register</button>
                  </div>            
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SignIn